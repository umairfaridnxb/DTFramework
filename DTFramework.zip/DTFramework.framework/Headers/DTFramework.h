//
//  DTFramework.h
//  DTFramework
//
//  Created by Umair Farid on 10/12/2018.
//  Copyright © 2018 Umair Farid. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for DTFramework.
FOUNDATION_EXPORT double DTFrameworkVersionNumber;

//! Project version string for DTFramework.
FOUNDATION_EXPORT const unsigned char DTFrameworkVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <DTFramework/PublicHeader.h>


